import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("2bc470f6-8d50-4194-8958-543b19b69e53")
public class Projet {
    @objid ("61f5ae50-34e3-4bd8-a8b4-33be5e7860b9")
    private int IDprojet;

    @objid ("b09931f1-18cf-4b25-a869-ae65c394247d")
    private String nom;

    @objid ("4900c845-13ec-4458-93c5-179437d55eab")
    private Date DateDebut;

    @objid ("05cf8a43-4281-495f-b60c-cf599ac59699")
    private float Budget;

    @objid ("98bdd8e6-06db-46e7-84b0-32db9991e9e5")
    public List<Activite> activite = new ArrayList<Activite> ();

    @objid ("aaf1b7f8-707b-440b-8625-13f5bacf5aba")
    public void AjouterActivite() {
    }

}
