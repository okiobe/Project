package Diagramme de classe;

import java.util.ArrayList;
import java.util.List;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("290fb1fa-4dc3-42d5-a1e6-3e205168e312")
public class Timelog {
    @objid ("71933880-ca02-4642-8bd6-8747c6be18b0")
    public List<Projet> projet = new ArrayList<Projet> ();

    @objid ("3a80b59b-f661-4621-aa7f-62e5d2e95131")
    public Activite activite;

    @objid ("a9d76e32-e810-4604-a99c-fb5b715fca62")
    public void Authentifier() {
    }

    @objid ("a81995e5-9820-4615-b298-b2bc38b89ef5")
    public void ObtenirListeProjets() {
    }

    @objid ("31f7e0d9-dfdc-402d-bad6-aabdb9ada98a")
    public void ObtenirListeActivite() {
    }

    @objid ("db4117e3-1c1d-440e-86d8-6d051124587e")
    public void EnregistrerDebutActivite() {
    }

    @objid ("9b94c963-ccfc-4832-bb56-c820f3964a3e")
    public void EnregistrerFinActivite() {
    }

}
