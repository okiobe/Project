package Diagramme de classe;

import java.util.Date;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("4ba0011f-c45e-4a0b-93e0-211dc2e33db6")
public class Activite {
    @objid ("ce54d7a6-1675-4b86-8aed-e17696e334da")
    private int IDActivite;

    @objid ("fbac2129-7659-4625-a0ef-932bafa8039c")
    private String nom;

    @objid ("7c4b9618-6b5e-43f7-a54f-b0aed9329d5d")
    private String discipline;

    @objid ("b1bfa1d4-8def-485f-bebb-9ec4454ac741")
    private Date DateDebut;

    @objid ("f54f10fe-5854-4e2f-aea3-1cdb4d0e49ee")
    private Date DateFin;

    @objid ("f78b7a92-9b7f-4f4a-a0c8-a2969f0684d7")
    private float HeureDeTravail;

    @objid ("8f4900d4-32d4-446d-8d1c-44f31cf9d681")
    public void Debuter() {
    }

    @objid ("6dcd319f-bef9-42b9-8c02-f26b1a3cf967")
    public void Terminer() {
    }

}
