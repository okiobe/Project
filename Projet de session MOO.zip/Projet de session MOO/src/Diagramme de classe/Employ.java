package Diagramme de classe;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("f2ead77d-8a4b-47ae-8891-2a90c182f2f0")
public class Employé {
    @objid ("3992eed5-7f36-47c8-b5c3-c316f98ec7bf")
    private int ID;

    @objid ("03cc82ab-fc52-42df-8edd-5b837685bbe2")
    private String nom;

    @objid ("847e48a5-6854-4773-a065-6d44535eac5a")
    private Date DateEmbauche;

    @objid ("d80d44b2-0dcd-4473-84f4-476402f8e44f")
    private float NAS;

    @objid ("48041b63-26bc-4ac5-a61a-69af09c8a7cf")
    private float TauxHoraire;

    @objid ("3f9f332d-478a-4e09-9364-0f6c06aacde6")
    public Timelog timelog;

    @objid ("2699c265-a068-4fbe-9dba-4aef9789fc88")
    public List<Projet> projet = new ArrayList<Projet> ();

    @objid ("fd58f253-b7d0-418d-8d3f-1a75ad53e84e")
    public List<Activite> activite = new ArrayList<Activite> ();

    @objid ("90bc2bf1-4862-499d-9f29-9c8e652ea58d")
    public void Seconnecter() {
    }

    @objid ("bac44342-db98-42dc-a830-4ac87f69ca62")
    public void SelectionnerProjet() {
    }

    @objid ("d3042240-b59e-4840-8fbd-3335bc36cca3")
    public void SelectionnerActivite() {
    }

    @objid ("68e03f7c-b838-4ede-b558-4d6a51e85dd7")
    public void DebuterActiviter() {
    }

    @objid ("96b354c2-3636-45ab-9310-582a37b007c8")
    public void TerminerActiviter() {
    }

}
