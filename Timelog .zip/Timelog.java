package diagrammedeclasse;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.io.FileWriter;
import java.io.FileReader;
import java.io.BufferedReader;
import java.io.IOException;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Timelog {
    private List<Activite> activites = new ArrayList<>();
    private Gson gson = new GsonBuilder().setPrettyPrinting().create();
    private Scanner scanner = new Scanner(System.in);
    private User user;

    // Classe interne pour représenter un utilisateur
    class User {
        private String name;
        private String id;

        public User(String name, String id) {
            this.name = name;
            this.id = id;
        }

        public String getName() {
            return name;
        }

        public String getId() {
            return id;
        }
    }

    // Classe interne pour les activités
    class Activite {
        private String nom;
        private User user;
        private String debut;
        private String fin;

        public Activite(String nom, User user, String debut, String fin) {
            this.nom = nom;
            this.user = user;
            this.debut = debut;
            this.fin = fin;
        }

        public String getNom() {
            return nom;
        }

        public User getUser() {
            return user;
        }

        public String getDebut() {
            return debut;
        }

        public String getFin() {
            return fin;
        }

        public void setFin(String fin) {
            this.fin = fin;
        }

        public String getDuree() {
            if (debut != null && fin != null) {
                LocalDateTime debutTime = LocalDateTime.parse(debut, DateTimeFormatter.ISO_LOCAL_DATE_TIME);
                LocalDateTime finTime = LocalDateTime.parse(fin, DateTimeFormatter.ISO_LOCAL_DATE_TIME);
                Duration duree = Duration.between(debutTime, finTime);
                return String.format("%d heures, %d minutes", duree.toHours(), duree.toMinutesPart());
            }
            return "En cours";
        }
    }

    public void Authentifier() {
        System.out.println("Entrez votre nom : ");
        String name = scanner.nextLine();
        System.out.println("Entrez votre ID : ");
        String id = scanner.nextLine();
        user = new User(name, id);
        sauvegarderUtilisateur();  // Sauvegarder l'utilisateur dans un fichier texte
        System.out.println("Authentification réussie pour l'utilisateur " + user.getName());
    }

    public void Demarrer() {
        chargerActivites(); // Charge les activités à partir du fichier JSON

        while (true) {
            System.out.println("\nSélectionnez une option :");
            System.out.println("1. Débuter une activité");
            System.out.println("2. Terminer une activité");
            System.out.println("3. Afficher la liste des activités");
            System.out.println("4. Quitter");
            System.out.print("Choix : ");

            int choix = scanner.nextInt();
            scanner.nextLine(); // Consomme la nouvelle ligne

            switch (choix) {
                case 1:
                    EnregistrerDebutActivite();
                    break;
                case 2:
                    EnregistrerFinActivite();
                    break;
                case 3:
                    AfficherActivites();
                    break;
                case 4:
                    System.out.println("Sortie du programme.");
                    scanner.close();
                    return;
                default:
                    System.out.println("Choix invalide. Veuillez réessayer.");
                    break;
            }
        }
    }

    public void EnregistrerDebutActivite() {
        System.out.println("Entrez le nom de l'activité : ");
        String nomActivite = scanner.nextLine();
        String heureDebut = LocalDateTime.now().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME);
        Activite nouvelleActivite = new Activite(nomActivite, user, heureDebut, null);
        activites.add(nouvelleActivite);
        sauvegarderActivites();
        System.out.println("Début de l'activité '" + nomActivite + "' enregistré à " + heureDebut + ".");
    }

    public void EnregistrerFinActivite() {
        if (!activites.isEmpty()) {
            Activite derniereActivite = activites.get(activites.size() - 1);
            if (derniereActivite.getFin() == null) { // Vérifie si l'activité n'a pas encore été terminée
                String heureFin = LocalDateTime.now().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME);
                derniereActivite.setFin(heureFin);
                sauvegarderActivites();
                System.out.println("Fin de l'activité '" + derniereActivite.getNom() + "' enregistrée à " + heureFin + ".");
                System.out.println("Durée de l'activité : " + derniereActivite.getDuree());
            } else {
                System.out.println("La dernière activité est déjà terminée.");
            }
        } else {
            System.out.println("Aucune activité en cours.");
        }
    }

    public void AfficherActivites() {
        System.out.println("Liste des activités enregistrées :");
        for (Activite act : activites) {
            System.out.println("Nom : " + act.getNom() +
                               ", Début : " + act.getDebut() +
                               ", Fin : " + (act.getFin() != null ? act.getFin() : "En cours") +
                               ", Durée : " + act.getDuree() +
                               ", Utilisateur : " + act.getUser().getName());
        }
    }

    public void sauvegarderActivites() {
        try (FileWriter writer = new FileWriter("activites.json")) {
            gson.toJson(activites, writer);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void chargerActivites() {
        try (FileReader reader = new FileReader("activites.json")) {
            Activite[] loadedActivites = gson.fromJson(reader, Activite[].class);
            if (loadedActivites != null) {
                for (Activite activite : loadedActivites) {
                    activites.add(activite);
                }
            }
        } catch (IOException e) {
            System.out.println("Aucune activité précédente n'a été trouvée.");
        }
    }

    // Sauvegarder les informations utilisateur dans un fichier texte
    public void sauvegarderUtilisateur() {
        try (FileWriter writer = new FileWriter("utilisateurs.txt", true)) { // Mode append
            writer.write(user.getName() + "," + user.getId() + "\n");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        Timelog timelog = new Timelog();
        timelog.Authentifier();
        timelog.Demarrer();
    }
}
